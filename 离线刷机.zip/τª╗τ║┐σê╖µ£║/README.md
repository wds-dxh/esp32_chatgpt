<!--
 * @Author: wds-Ubuntu22-cqu wdsnpshy@163.com
 * @Date: 2024-12-10 19:25:57
 * @Description: `
 * 邮箱：wdsnpshy@163.com 
 * Copyright (c) 2024 by ${wds-Ubuntu22-cqu}, All Rights Reserved. 
-->
刷机命令
```shell
pio run --target nobuild --target upload --upload-port /dev/ttyCH341USB0
```